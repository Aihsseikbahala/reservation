<?php
    require_once("../object/student.php");

    $id = 0; //isset($_POST['id']) ? $_POST['id'] : 0;
    $fname = 'Altareste'; //isset($_POST['fname']) ? $_POST['fname'] : '';
    $lname = 'Obidas'; //isset($_POST['lname']) ? $_POST['lname'] : '';
    $gender = 'Female'; //isset($_POST['gender']) ? $_POST['gender'] : '';
    $birthday = '02/14/1976'; //isset($_POST['birthday']) ? $_POST['birthday'] : '';

    $stud = array(
        "id"=>$id,
        "fname"=>$fname,
        "lname"=>$lname,
        "gender"=>$gender,
        "birthday"=>$birthday
    );

    $student = new Student();
    $ret = $student->saveUpdateStudent($stud);
    echo $ret //$student->getState();
?>