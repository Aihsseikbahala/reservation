<?php
     header("Access-Control-Allow-Origin: *");
     // header("Content-Type: application/json; charset=UTF-8");
     header("Access-Control-Allow-Methods: POST");
     header("Access-Control-Max-Age: 3600");
     header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    //  session_start();
     require_once("../object/student.php");

     $method = isset($_POST['method']) ? $_POST['method'] : exit();
       
     if(function_exists($method)){
         call_user_func($method);
     }else{
         exit();
     }

     function saveStudent(){
   
        $fname = isset($_POST['fname']) ? $_POST['fname'] : '';
        $lname = isset($_POST['lname']) ? $_POST['lname'] : '';
        $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
        $birthday = isset($_POST['birthday']) ? $_POST['birthday'] : '';
    
        $stud = array(
            "fname"=>$fname,
            "lname"=>$lname,
            "gender"=>$gender,
            "birthday"=>$birthday
        );
    
        $student = new Student();
        $ret = $student->saveUpdateStudent($stud);
        echo json_encode($ret);
     }

     function getAllStudent(){
        $student = new Student();
        echo json_encode($student->disPlayAllStudent());
     }
    
     function updateStudent(){
        $id = isset($_POST['id']) ? $_POST['id'] : 0;
        $fname = isset($_POST['fname']) ? $_POST['fname'] : '';
        $lname = isset($_POST['lname']) ? $_POST['lname'] : '';
        $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
        $birthday = isset($_POST['birthday']) ? $_POST['birthday'] : '';
    
        $stud = array(
            "id"=>$id,
            "fname"=>$fname,
            "lname"=>$lname,
            "gender"=>$gender,
            "birthday"=>$birthday
        );

        $s = new Student();
        $ret = $s->updateStudent($stud);
        echo json_encode($ret);

     }
     

?>