<?php
    require_once("../config/config.php");

    Class Student{
        private $dbcon;
        private $state;
        private $errmsg;

        public function __construct(){
            try{
                $db = new Database();
                if($db->getState()){
                    $this->dbcon = $db->getDb();
                    $this->state = true;
                    $this->errmsg = "Connected";
                }else{
                    $this->state = false;
                    $this->errmsg = $db->getErrMsg();
                }
            }
            catch(Exception $e){
                     $this->state = false;
                     $this->errmsg = $e->getMessage();
            }
        }
        
        public function getState(){
            return $this->state;
        }
        public function saveUpdateStudent($stud){
            $sql = "call sp_insertStudent(:fname,:lname,:gender,:birthday)";

            $stmt = $this->dbcon->prepare($sql);
            // $stmt->bindParam(':id',$stud['id']);
            $stmt->bindParam(':fname',$stud['fname']);
            $stmt->bindParam(':lname',$stud['lname']);
            $stmt->bindParam(':gender',$stud['gender']);
            $stmt->bindParam(':birthday',$stud['birthday']);
            try{
                $stmt->execute();
                if($stmt){
                    return 1;
                }else{
                    return 0;
                }
            }catch(Exception $ex){
                $this->errmsg = $ex->getMessage();
                echo $ex->getMessage();
                return -1;
            }
        }

        public function disPlayAllStudent(){
            $sql = "call getAllStudent()";

            $stmt = $this->dbcon->prepare($sql);
                 try{
                     $stmt->execute();
                     if($stmt){
                       $rows = array();
                       while($rw = $stmt->fetch(PDO::FETCH_ASSOC)){
                           $rows[] = $rw;
                       }
                       return $rows;
                     }else{  
                         return array();
                     }
                 }catch(PDOException $ex){
                     $this->state = false;
                     return $ex->getMessage();
                 }
        }
        public function updateStudent($stud){
            $sql = "call studUpdate(:id,:fname,:lname,:gender,:birthday)";

            $stmt = $this->dbcon->prepare($sql);
            $stmt->bindParam(':id',$stud['id']);
            $stmt->bindParam(':fname',$stud['fname']);
            $stmt->bindParam(':lname',$stud['lname']);
            $stmt->bindParam(':gender',$stud['gender']);
            $stmt->bindParam(':birthday',$stud['birthday']);
            try{
                $stmt->execute();
                if($stmt){
                    return 1;
                }else{
                    return 0;
                }
            }catch(Exception $ex){
                $this->errmsg = $ex->getMessage();
                echo $ex->getMessage();
                return -1;
            }
        }
    }
?>